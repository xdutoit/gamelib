// écrivez ici tout le script de votre jeu
alert('ça marche !');
